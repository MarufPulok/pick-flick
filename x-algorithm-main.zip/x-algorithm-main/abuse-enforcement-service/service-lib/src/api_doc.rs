use serde::{Deserialize, Serialize};
use utoipa::{
    openapi::security::{HttpAuthScheme, HttpBuilder, SecurityScheme},
    Modify, OpenApi, ToSchema,
};

use crate::service;

pub struct SecurityAddon;

impl Modify for SecurityAddon {
    fn modify(&self, openapi: &mut utoipa::openapi::OpenApi) {
        let components = openapi.components.get_or_insert_with(Default::default);
        components.add_security_scheme(
            "BearerAuth",
            SecurityScheme::Http(HttpBuilder::new().scheme(HttpAuthScheme::Bearer).build()),
        );
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ApiError {
    pub error: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct DryRunStatus {
    pub dry_run: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct RateLimitStats {
    pub used: u64,
    pub cap: u64,
    pub remaining: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct AllowlistDeleteResponse {
    pub user_id: i64,
    pub removed: bool,
}

#[derive(OpenApi)]
#[openapi(
    modifiers(&SecurityAddon),
    paths(
        service::handle_action,
        service::handle_config,
        service::handle_dry_run,
        service::handle_rate_limit,
        service::handle_rate_limit_increment,
        service::handle_rate_limit_reset,
        service::handle_dedup_get,
        service::handle_dedup_get_entity,
        service::handle_allowlist_list,
        service::handle_allowlist_get,
        service::handle_config_put,
        service::handle_config_patch_field,
        service::handle_rules_get,
        service::handle_allowlist_put,
        service::handle_allowlist_delete,
        service::handle_allowlist_bulk,
        service::handle_allowlist_get_entity,
        service::handle_allowlist_put_entity,
        service::handle_allowlist_delete_entity,
    ),
    components(schemas(
        xai_abuse_enforcement_types::allowlist::AllowlistEntry,
        xai_abuse_enforcement_types::allowlist::AllowlistRecord,
        xai_abuse_enforcement_types::allowlist::AllowlistAddRequest,
        xai_abuse_enforcement_types::allowlist::AllowlistBulkRequest,
        xai_abuse_enforcement_types::allowlist::AllowlistBulkEntry,
        xai_abuse_enforcement_types::allowlist::BulkResponse,
        xai_abuse_enforcement_types::allowlist::BulkRowResult,
        xai_abuse_enforcement_types::config::ConfigPatchRequest,
        ApiError,
        DryRunStatus,
        RateLimitStats,
        AllowlistDeleteResponse,
    )),
    tags(
        (name = "config", description = "🔒 PROTECTED (bearer token). GrowthBook config — read + write."),
        (name = "allowlist", description = "🔒 PROTECTED (bearer token). Allowlist — read + write (single + bulk)."),
        (name = "debug", description = "Open (no auth) ops/debug endpoints — dry-run flag, rate-limit usage, dedup lookup — EXCEPT POST /action and both rate-limit writes (POST /rate_limit and POST /rate_limit/reset), which are 🔒 protected because they mutate the enforcement budget. Look for the lock icon per endpoint."),
    ),
    servers(
        (url = "/api", description = "API base"),
    ),
    info(
        title = "xai-abuse-enforcement-service",
        description = "HTTP API for the xAI abuse-enforcement system. Used by the slackbot + the embedded admin UI at /admin.\n\n\
        **Auth:** endpoints with a 🔒 lock icon require `Authorization: Bearer <token>` — click **Authorize** and paste a key. \
        PROTECTED: everything under `config` + `allowlist`, plus `POST /action`, `POST /rate_limit` and `POST /rate_limit/reset`. \
        OPEN (no auth): `GET /dry_run`, `GET /rate_limit`, `GET /dedup/{user_id}`.",
    ),
)]
pub struct ApiDoc;

#[cfg(test)]
mod tests {
    use super::*;
    use utoipa::OpenApi;

    const EXPECTED_OPERATIONS: &[(&str, &str, bool)] = &[
        ("/action", "post", true),
        ("/config", "get", true),
        ("/config", "put", true),
        ("/config/{field}", "patch", true),
        ("/rules", "get", true),
        ("/dry_run", "get", false),
        ("/rate_limit/{entity_type}", "get", false),
        ("/rate_limit/{entity_type}", "post", true),
        ("/rate_limit/{entity_type}/reset", "post", true),
        ("/dedup/{user_id}", "get", false),
        ("/dedup/{entity_type}/{entity_id}", "get", false),
        ("/allowlist", "get", true),
        ("/allowlist/bulk", "post", true),
        ("/allowlist/{user_id}", "get", true),
        ("/allowlist/{user_id}", "put", true),
        ("/allowlist/{user_id}", "delete", true),
        ("/allowlist/{entity_type}/{entity_id}", "get", true),
        ("/allowlist/{entity_type}/{entity_id}", "put", true),
        ("/allowlist/{entity_type}/{entity_id}", "delete", true),
    ];

    #[test]
    fn openapi_doc_is_well_formed() {
        let doc = ApiDoc::openapi();
        let json = serde_json::to_value(&doc).expect("doc serializes to JSON");

        let paths = json
            .get("paths")
            .and_then(|v| v.as_object())
            .expect("`paths` is an object");

        let mut got: std::collections::BTreeMap<(String, String), bool> =
            std::collections::BTreeMap::new();
        for (path, item) in paths {
            for (method, op) in item.as_object().expect("path item is an object") {
                let has_security = op
                    .get("security")
                    .and_then(|v| v.as_array())
                    .map(|a| !a.is_empty())
                    .unwrap_or(false);
                got.insert((path.clone(), method.clone()), has_security);
            }
        }

        let expected_keys: std::collections::BTreeSet<(String, String)> = EXPECTED_OPERATIONS
            .iter()
            .map(|(p, m, _)| ((*p).to_owned(), (*m).to_owned()))
            .collect();
        let got_keys: std::collections::BTreeSet<(String, String)> = got.keys().cloned().collect();
        let missing: Vec<_> = expected_keys.difference(&got_keys).collect();
        let extra: Vec<_> = got_keys.difference(&expected_keys).collect();
        assert!(
            missing.is_empty() && extra.is_empty(),
            "ApiDoc operations drift — missing: {missing:?}, extra: {extra:?}",
        );

        let mut wrong: Vec<String> = Vec::new();
        for (path, method, want_protected) in EXPECTED_OPERATIONS {
            let key = ((*path).to_owned(), (*method).to_owned());
            let got_protected = *got.get(&key).expect("checked above");
            if got_protected != *want_protected {
                wrong.push(format!(
                    "{method} {path}: expected security={want_protected}, got security={got_protected}",
                ));
            }
        }
        assert!(
            wrong.is_empty(),
            "ApiDoc `security(...)` annotations disagree with the protected/public split \
             in `build_api_router`:\n  {}",
            wrong.join("\n  "),
        );

        let schemes = json
            .pointer("/components/securitySchemes")
            .and_then(|v| v.as_object())
            .expect("componentss.securitySchemes must be an object");
        assert!(
            schemes.contains_key("BearerAuth"),
            "BearerAuth security scheme missing — `SecurityAddon` modifier didn't run? \
             schemes={schemes:?}",
        );

        let declared_tags: std::collections::HashSet<String> = doc
            .tags
            .as_ref()
            .map(|t| t.iter().map(|tag| tag.name.clone()).collect())
            .unwrap_or_default();
        let mut handler_tags: std::collections::HashSet<String> = std::collections::HashSet::new();
        for (_path, item) in paths {
            for (_method, op) in item.as_object().expect("path item is an object") {
                if let Some(tags) = op.get("tags").and_then(|v| v.as_array()) {
                    for t in tags {
                        if let Some(s) = t.as_str() {
                            handler_tags.insert(s.to_string());
                        }
                    }
                }
            }
        }
        let undeclared: Vec<&String> = handler_tags.difference(&declared_tags).collect();
        assert!(
            undeclared.is_empty(),
            "handlers reference tags not declared in tags(...): {undeclared:?}",
        );
    }
}
